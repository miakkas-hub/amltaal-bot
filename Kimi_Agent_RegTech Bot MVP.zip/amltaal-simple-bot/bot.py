"""
امتثال+ - بوت تليجرام بسيط
"""

import os
import logging
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# إعدادات
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# بيانات
observations = []
counter = 1

def get_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 لوحة التحكم", callback_data="dash")],
        [InlineKeyboardButton("📝 ملاحظة جديدة", callback_data="new_menu")],
        [InlineKeyboardButton("📋 الملاحظات المفتوحة", callback_data="open")],
        [InlineKeyboardButton("⏱️ SLA", callback_data="sla")],
        [InlineKeyboardButton("❓ المساعدة", callback_data="help")],
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    await update.message.reply_text(
        f"👋 أهلاً {user.first_name}!\n\n"
        "🎯 امتثال+ - منصة الالتزام التنظيمي\n\n"
        "📊 إدارة الملاحظات الرقابية\n"
        "⏱️ مراقبة SLA\n\n"
        "اختر من القائمة:",
        reply_markup=get_menu()
    )

async def dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global counter
    open_obs = [o for o in observations if o["status"] == "مفتوحة"]
    overdue = [o for o in open_obs if datetime.now() > o["target"]]
    critical = [o for o in open_obs if o["priority"] == "🔴 حرج"]
    
    text = (
        "📊 لوحة التحكم\n"
        "━━━━━━━━━━━━\n"
        f"📋 الملاحظات: {len(observations)}\n"
        f"🔓 المفتوحة: {len(open_obs)}\n"
        f"🔴 الحرجة: {len(critical)}\n"
        f"⏰ المتأخرة: {len(overdue)}\n"
        f"📈 الالتزام: {((len(open_obs)-len(overdue))/max(len(open_obs),1)*100):.0f}%\n"
        "━━━━━━━━━━━━"
    )
    
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, reply_markup=get_menu())
    else:
        await update.message.reply_text(text, reply_markup=get_menu())

async def new_obs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global counter
    text = " ".join(context.args).strip()
    
    if not text:
        if update.callback_query:
            await update.callback_query.answer()
            await update.callback_query.edit_message_text(
                "📝 لإضافة ملاحظة، اكتب:\n"
                "<code>/new عنوان الملاحظة | الأولوية | الإدارة</code>\n\n"
                "مثال:\n"
                "<code>/new نقص AML | عالي | المخاطر</code>",
                parse_mode="HTML",
                reply_markup=get_menu()
            )
        else:
            await update.message.reply_text(
                "📝 لإضافة ملاحظة، اكتب:\n"
                "<code>/new عنوان الملاحظة | الأولوية | الإدارة</code>\n\n"
                "مثال:\n"
                "<code>/new نقص AML | عالي | المخاطر</code>",
                parse_mode="HTML",
                reply_markup=get_menu()
            )
        return
    
    parts = [p.strip() for p in text.split("|")]
    title = parts[0]
    priority_text = parts[1] if len(parts) > 1 else "متوسط"
    dept = parts[2] if len(parts) > 2 else "غير محدد"
    
    priorities = {"حرج": "🔴 حرج", "عالي": "🟠 عالي", "متوسط": "🟡 متوسط", "منخفض": "🟢 منخفض"}
    priority = priorities.get(priority_text, "🟡 متوسط")
    
    obs = {
        "id": f"OBS-2025-{counter:04d}",
        "title": title,
        "priority": priority,
        "department": dept,
        "status": "مفتوحة",
        "created": datetime.now(),
        "target": datetime.now() + timedelta(days=14),
    }
    observations.append(obs)
    counter += 1
    
    await update.message.reply_text(
        f"✅ تم إنشاء الملاحظة!\n\n"
        f"📋 {obs['id']}\n"
        f"📌 {title}\n"
        f"🎯 {priority}\n"
        f"🏢 {dept}\n"
        f"📅 {obs['target'].strftime('%Y-%m-%d')}",
        reply_markup=get_menu()
    )

async def open_points(update: Update, context: ContextTypes.DEFAULT_TYPE):
    open_obs = [o for o in observations if o["status"] == "مفتوحة"]
    now = datetime.now()
    
    if not open_obs:
        text = "✅ لا توجد ملاحظات مفتوحة!"
    else:
        text = f"📋 الملاحظات المفتوحة ({len(open_obs)})\n\n"
        for obs in sorted(open_obs, key=lambda x: x["target"]):
            late = " ⏰ متأخرة" if now > obs["target"] else ""
            days = (obs["target"] - now).days
            status = f"متبقي {days} يوم" if days >= 0 else f"متأخر {abs(days)} يوم"
            text += f"{obs['priority']} {obs['id']}{late}\n📌 {obs['title'][:40]}\n🏢 {obs['department']} | 📅 {status}\n\n"
    
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, reply_markup=get_menu())
    else:
        await update.message.reply_text(text, reply_markup=get_menu())

async def sla_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    open_obs = [o for o in observations if o["status"] == "مفتوحة"]
    now = datetime.now()
    overdue = [o for o in open_obs if now > o["target"]]
    rate = ((len(open_obs)-len(overdue)) / max(len(open_obs), 1)) * 100
    filled = int(rate / 10)
    bar = "█" * filled + "░" * (10 - filled)
    
    text = (
        f"⏱️ حالة SLA\n"
        f"━━━━━━━━━━━━\n"
        f"[{bar}] {rate:.0f}%\n\n"
        f"📋 الكلي: {len(open_obs)}\n"
        f"✅ في الموعد: {len(open_obs) - len(overdue)}\n"
        f"⏰ المتأخر: {len(overdue)}\n"
        f"━━━━━━━━━━━━"
    )
    
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, reply_markup=get_menu())
    else:
        await update.message.reply_text(text, reply_markup=get_menu())

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "❓ دليل الاستخدام\n\n"
        "/start - البداية\n"
        "/dashboard - لوحة التحكم\n"
        "/new - إضافة ملاحظة\n"
        "/open - الملاحظات المفتوحة\n"
        "/sla - حالة SLA\n"
        "/help - المساعدة\n\n"
        "📝 إضافة ملاحظة:\n"
        "<code>/new عنوان | أولوية | إدارة</code>\n"
        "مثال: <code>/new نقص AML | عالي | المخاطر</code>"
    )
    
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, parse_mode="HTML", reply_markup=get_menu())
    else:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=get_menu())

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    
    if data == "dash":
        await dashboard(update, context)
    elif data == "new_menu":
        await query.answer()
        await query.edit_message_text(
            "📝 اكتب الأمر:\n"
            "<code>/new عنوان | أولوية | إدارة</code>",
            parse_mode="HTML",
            reply_markup=get_menu()
        )
    elif data == "open":
        await open_points(update, context)
    elif data == "sla":
        await sla_status(update, context)
    elif data == "help":
        await help_cmd(update, context)

def main():
    logger.info("=" * 40)
    logger.info("امتثال+ - بدء التشغيل")
    logger.info(f"BOT_TOKEN موجود: {'نعم' if BOT_TOKEN else 'لا'}")
    logger.info("=" * 40)
    
    if not BOT_TOKEN:
        logger.error("ERROR: BOT_TOKEN غير موجود!")
        return
    
    app = Application.builder().token(BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("dashboard", dashboard))
    app.add_handler(CommandHandler("new", new_obs))
    app.add_handler(CommandHandler("open", open_points))
    app.add_handler(CommandHandler("sla", sla_status))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CallbackQueryHandler(buttons))
    
    logger.info("✅ البوت جاهز!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
