# امتثال+ - بوت تليجرام البسيط

## خطوات التشغيل على Railway

### 1. رفع الملفات على GitHub
- افتح https://github.com/new
- اسم المستودع: `amltaal-bot`
- اضغط **Create repository**
- اضغط **uploading an existing file**
- ارفع `bot.py` و `requirements.txt` و `railway.toml`
- اضغط **Commit changes**

### 2. تشغيل على Railway
- افتح https://railway.app
- سجل دخول بـ GitHub
- **New Project** → **Deploy from GitHub repo** → اختار `amltaal-bot`
- اضغط على **Variables** (فوق)
- **New Variable**:
  - Name: `BOT_TOKEN`
  - Value: توكنك من BotFather
- اضغط **Add**
- اضغط **Deploy**

### 3. التأكد من الاشتغال
- اضغط على **Logs** (فوق) في Railway
- لازم يطلع:
  ```
  امتثال+ - بدء التشغيل
  BOT_TOKEN موجود: نعم
  البوت جاهز!
  ```
- افتح Telegram وارسل `/start`

## لو ما اشتغل
1. اضغط **Logs** في Railway
2. انسخ آخر 5 أسطر من الـ logs
3. ارسلها لي
