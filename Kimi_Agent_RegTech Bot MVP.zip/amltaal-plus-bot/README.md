# امتثال+ - بوت تليجرام

بوت إدارة الالتزام التنظيمي والملاحظات الرقابية.

---

## 🚀 طريقة التشغيل على Railway (أسهل طريقة)

### الخطوة 1: رفع الملفات على GitHub

1. افتح https://github.com/new
2. اسم المستودع: `amltaal-bot`
3. اضغط **Create repository**
4. اضغط **uploading an existing file**
5. ارفع الملفات الأربعة (bot.py, requirements.txt, railway.toml, Procfile)
6. اضغط **Commit changes**

### الخطوة 2: تشغيل على Railway

1. افتح https://railway.app
2. سجل دخول بـ GitHub
3. اضغط **New Project**
4. اختار **Deploy from GitHub repo**
5. اختار مستودع `amltaal-bot`
6. اضغط **Add Variables**
7. ضيف:
   - Name: `BOT_TOKEN`
   - Value: التوكن اللي جاك من BotFather
8. اضغط **Add** ثم **Deploy**

### ✅ جاهز!

افتح البوت في Telegram وارسل `/start`

---

## 🎯 أوامر البوت

| الأمر | الوظيفة |
|-------|---------|
| `/start` | البداية والقائمة |
| `/dashboard` | لوحة التحكم |
| `/add` | إضافة ملاحظة تفصيلية |
| `/new` | إضافة ملاحظة سريعة |
| `/open` | الملاحظات المفتوحة |
| `/sla` | حالة SLA |
| `/help` | المساعدة |
| `/cancel` | إلغاء العملية |

---

## 📁 الملفات

| الملف | الوظيفة |
|-------|---------|
| `bot.py` | البوت الرئيسي |
| `requirements.txt` | المكتبات المطلوبة |
| `railway.toml` | إعدادات Railway |
| `Procfile` | أمر التشغيل |
