"""
امتثال+ - بوت تليجرام لإدارة الالتزام التنظيمي
Amltaal Plus - Regulatory Compliance Telegram Bot

المميزات:
- إدارة الملاحظات الرقابية (Observations)
- متابعة SLA والمواعيد النهائية
- تقارير وإحصائيات
- نظام أولويات وإدارات
"""

import os
import logging
import asyncio
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

# ═══════════════════════════════════════════
# إعدادات البوت
# ═══════════════════════════════════════════

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

if not BOT_TOKEN:
    print("=" * 50)
    print("ERROR: يرجى تعيين متغير البيئة BOT_TOKEN")
    print("In Railway: Go to Variables -> New Variable")
    print("Name: BOT_TOKEN")
    print("Value: your_telegram_bot_token")
    print("=" * 50)
    exit(1)

# إعداد التسجيل
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════
# حالة المحادثة
# ═══════════════════════════════════════════

(ADDING_TITLE, ADDING_PRIORITY, ADDING_DEPT, ADDING_DAYS) = range(4)

# ═══════════════════════════════════════════
# قاعدة البيانات المؤقتة (في الذاكرة)
# ═══════════════════════════════════════════

observations = []
users = {}
counter = {"obs": 1}


def generate_obs_id():
    """توليد رقم ملاحظة تسلسلي"""
    obs_id = f"OBS-2025-{counter['obs']:04d}"
    counter["obs"] += 1
    return obs_id


def priority_emoji(priority: str) -> str:
    """تحويل نص الأولوية لإيموجي"""
    mapping = {
        "حرج": "🔴 حرج",
        "عالي": "🟠 عالي",
        "متوسط": "🟡 متوسط",
        "منخفض": "🟢 منخفض",
    }
    return mapping.get(priority, "🟡 متوسط")


def main_menu_keyboard():
    """لوحة المفاتيح الرئيسية"""
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("📊 لوحة التحكم", callback_data="dashboard"),
                InlineKeyboardButton("📝 ملاحظة جديدة", callback_data="new_obs"),
            ],
            [
                InlineKeyboardButton("📋 الملاحظات المفتوحة", callback_data="open_obs"),
                InlineKeyboardButton("📁 جميع الملاحظات", callback_data="all_obs"),
            ],
            [
                InlineKeyboardButton("⏱️ حالة SLA", callback_data="sla"),
                InlineKeyboardButton("🔴 الحرجة", callback_data="critical"),
            ],
            [
                InlineKeyboardButton("❓ المساعدة", callback_data="help"),
                InlineKeyboardButton("🔄 تحديث", callback_data="dashboard"),
            ],
        ]
    )


def back_keyboard():
    """زر العودة للقائمة الرئيسية"""
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("🔙 العودة للقائمة", callback_data="dashboard")]]
    )


# ═══════════════════════════════════════════
# الأوامر الرئيسية
# ═══════════════════════════════════════════


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر /start - البداية"""
    user = update.effective_user
    users[user.id] = {
        "name": user.first_name,
        "username": user.username,
        "joined": datetime.now().isoformat(),
    }

    text = (
        f"👋 أهلاً <b>{user.first_name}</b>!\n\n"
        f"🎯 <b>امتثال+</b> - منصة الالتزام التنظيمي\n\n"
        f"📊 إدارة الملاحظات الرقابية\n"
        f"📝 متابعة طلبات الهيئات الرقابية\n"
        f"⏱️ مراقبة SLA والمواعيد النهائية\n\n"
        f"اختر من القائمة أدناه:"
    )

    await update.message.reply_text(
        text, parse_mode="HTML", reply_markup=main_menu_keyboard()
    )


async def dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """لوحة التحكم الرئيسية"""
    query = update.callback_query
    if query:
        await query.answer()

    total = len(observations)
    open_obs = [o for o in observations if o["status"] == "مفتوحة"]
    closed = [o for o in observations if o["status"] == "مغلقة"]
    critical = [o for o in open_obs if "حرج" in o["priority"]]
    overdue = [o for o in open_obs if datetime.now() > o["target_date"]]

    # تحديث حالة المتأخرة تلقائياً
    for obs in open_obs:
        obs["overdue"] = datetime.now() > obs["target_date"]

    compliance_rate = (
        ((len(open_obs) - len(overdue)) / max(len(open_obs), 1)) * 100
    )

    text = (
        f"📊 <b>لوحة التحكم</b>\n"
        f"<code>━━━━━━━━━━━━━━━━━━━━</code>\n"
        f"📋 إجمالي الملاحظات: <b>{total}</b>\n"
        f"🔓 المفتوحة: <b>{len(open_obs)}</b>\n"
        f"🔒 المغلقة: <b>{len(closed)}</b>\n"
        f"🔴 الحرجة: <b>{len(critical)}</b>\n"
        f"⏰ المتأخرة: <b>{len(overdue)}</b>\n"
        f"📈 نسبة الالتزام: <b>{compliance_rate:.0f}%</b>\n"
        f"<code>━━━━━━━━━━━━━━━━━━━━</code>\n"
        f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    )

    if query:
        await query.edit_message_text(
            text, parse_mode="HTML", reply_markup=main_menu_keyboard()
        )
    else:
        await update.message.reply_text(
            text, parse_mode="HTML", reply_markup=main_menu_keyboard()
        )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر المساعدة"""
    query = update.callback_query
    if query:
        await query.answer()

    text = (
        f"❓ <b>دليل استخدام امتثال+</b>\n\n"
        f"📋 <b>الأوامر:</b>\n"
        f"/start - بدء البوت\n"
        f"/dashboard - لوحة التحكم\n"
        f"/new - إضافة ملاحظة سريعة\n"
        f"/open - الملاحظات المفتوحة\n"
        f"/sla - حالة SLA\n"
        f"/help - هذا الدليل\n\n"
        f"📝 <b>إضافة ملاحظة سريعة:</b>\n"
        f"<code>/new عنوان الملاحظة</code>\n\n"
        f"أو اضغط 📝 ملاحظة جديدة للإضافة التفصيلية."
    )

    if query:
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=back_keyboard())
    else:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=back_keyboard())


# ═══════════════════════════════════════════
# إضافة ملاحظة جديدة (محادثة تفاعلية)
# ═══════════════════════════════════════════


async def new_obs_conversation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """بدء محادثة إضافة ملاحظة"""
    query = update.callback_query
    if query:
        await query.answer()
        await query.edit_message_text(
            "📝 <b>إضافة ملاحظة جديدة</b>\n\n"
            "الخطوة 1 من 4\n"
            "اكتب عنوان الملاحظة:",
            parse_mode="HTML",
        )
    else:
        await update.message.reply_text(
            "📝 <b>إضافة ملاحظة جديدة</b>\n\n"
            "الخطوة 1 من 4\n"
            "اكتب عنوان الملاحظة:",
            parse_mode="HTML",
        )

    return ADDING_TITLE


async def add_title(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """استقبال عنوان الملاحظة"""
    context.user_data["obs_title"] = update.message.text

    keyboard = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("🔴 حرج", callback_data="prio_حرج")],
            [InlineKeyboardButton("🟠 عالي", callback_data="prio_عالي")],
            [InlineKeyboardButton("🟡 متوسط", callback_data="prio_متوسط")],
            [InlineKeyboardButton("🟢 منخفض", callback_data="prio_منخفض")],
        ]
    )

    await update.message.reply_text(
        "📝 <b>إضافة ملاحظة جديدة</b>\n\n"
        f"العنوان: {context.user_data['obs_title']}\n\n"
        "الخطوة 2 من 4\n"
        "اختر الأولوية:",
        parse_mode="HTML",
        reply_markup=keyboard,
    )

    return ADDING_PRIORITY


async def add_priority(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """استقبال الأولوية"""
    query = update.callback_query
    await query.answer()

    priority = query.data.replace("prio_", "")
    context.user_data["obs_priority"] = priority

    await query.edit_message_text(
        "📝 <b>إضافة ملاحظة جديدة</b>\n\n"
        f"العنوان: {context.user_data['obs_title']}\n"
        f"الأولوية: {priority_emoji(priority)}\n\n"
        "الخطوة 3 من 4\n"
        "اكتب اسم الإدارة المختصة:",
        parse_mode="HTML",
    )

    return ADDING_DEPT


async def add_department(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """استقبال الإدارة"""
    context.user_data["obs_dept"] = update.message.text

    keyboard = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("7 أيام", callback_data="days_7")],
            [InlineKeyboardButton("14 يوم", callback_data="days_14")],
            [InlineKeyboardButton("30 يوم", callback_data="days_30")],
            [InlineKeyboardButton("60 يوم", callback_data="days_60")],
        ]
    )

    await update.message.reply_text(
        "📝 <b>إضافة ملاحظة جديدة</b>\n\n"
        f"الإدارة: {context.user_data['obs_dept']}\n\n"
        "الخطوة 4 من 4\n"
        "اختر المدة (أيام للإغلاق):",
        parse_mode="HTML",
        reply_markup=keyboard,
    )

    return ADDING_DAYS


async def add_days(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """استقبال المدة وإنشاء الملاحظة"""
    query = update.callback_query
    await query.answer()

    days = int(query.data.replace("days_", ""))
    title = context.user_data["obs_title"]
    priority = context.user_data["obs_priority"]
    dept = context.user_data["obs_dept"]

    now = datetime.now()
    obs = {
        "id": generate_obs_id(),
        "title": title,
        "priority": priority_emoji(priority),
        "department": dept,
        "status": "مفتوحة",
        "created": now,
        "target_date": now + timedelta(days=days),
        "overdue": False,
        "comments": [],
    }

    observations.append(obs)

    await query.edit_message_text(
        f"✅ <b>تم إنشاء الملاحظة بنجاح!</b>\n\n"
        f"📋 الرقم: <code>{obs['id']}</code>\n"
        f"📌 {title}\n"
        f"🎯 الأولوية: {obs['priority']}\n"
        f"🏢 الإدارة: {dept}\n"
        f"📅 تاريخ الاستحقاق: {obs['target_date'].strftime('%Y-%m-%d')}\n\n"
        f"تم حفظ الملاحظة في النظام.",
        parse_mode="HTML",
        reply_markup=back_keyboard(),
    )

    return ConversationHandler.END


async def cancel_conversation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """إلغاء المحادثة"""
    await update.message.reply_text(
        "❌ تم إلغاء العملية.", reply_markup=main_menu_keyboard()
    )
    return ConversationHandler.END


# ═══════════════════════════════════════════
# أوامر سريعة
# ═══════════════════════════════════════════


async def new_quick(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """إضافة ملاحظة سريعة بالأمر /new"""
    text = " ".join(context.args)
    if not text:
        await update.message.reply_text(
            "📝 <b>إضافة ملاحظة سريعة</b>\n\n"
            "الاستخدام: <code>/new عنوان الملاحظة</code>\n"
            "مثال: <code>/new نقص في إجراءات AML</code>",
            parse_mode="HTML",
            reply_markup=back_keyboard(),
        )
        return

    obs = {
        "id": generate_obs_id(),
        "title": text,
        "priority": "🟡 متوسط",
        "department": "غير محدد",
        "status": "مفتوحة",
        "created": datetime.now(),
        "target_date": datetime.now() + timedelta(days=14),
        "overdue": False,
        "comments": [],
    }

    observations.append(obs)

    await update.message.reply_text(
        f"✅ <b>تم إنشاء الملاحظة!</b>\n\n"
        f"📋 الرقم: <code>{obs['id']}</code>\n"
        f"📌 {text}\n"
        f"📅 تاريخ الاستحقاق: {obs['target_date'].strftime('%Y-%m-%d')}",
        parse_mode="HTML",
        reply_markup=back_keyboard(),
    )


async def open_points(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض الملاحظات المفتوحة"""
    query = update.callback_query
    if query:
        await query.answer()

    open_obs = [o for o in observations if o["status"] == "مفتوحة"]
    now = datetime.now()

    for obs in open_obs:
        obs["overdue"] = now > obs["target_date"]

    if not open_obs:
        text = "✅ لا توجد ملاحظات مفتوحة حالياً!"
    else:
        text = f"📋 <b>الملاحظات المفتوحة ({len(open_obs)})</b>\n\n"
        for obs in sorted(open_obs, key=lambda x: x["target_date"]):
            overdue_mark = " ⏰ متأخرة!" if obs["overdue"] else ""
            days_left = (obs["target_date"] - now).days
            status_date = f"متبقي {days_left} يوم" if days_left >= 0 else f"متأخر {abs(days_left)} يوم"

            text += (
                f"{obs['priority']} <code>{obs['id']}</code>{overdue_mark}\n"
                f"📌 {obs['title'][:60]}\n"
                f"🏢 {obs['department']} | 📅 {status_date}\n\n"
            )

    if query:
        await query.edit_message_text(
            text[:4000], parse_mode="HTML", reply_markup=back_keyboard()
        )
    else:
        await update.message.reply_text(
            text[:4000], parse_mode="HTML", reply_markup=back_keyboard()
        )


async def all_observations(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض جميع الملاحظات"""
    query = update.callback_query
    await query.answer()

    if not observations:
        text = "📁 لا توجد ملاحظات مسجلة بعد."
    else:
        text = f"📁 <b>جميع الملاحظات ({len(observations)})</b>\n\n"
        for obs in observations[-20:]:
            status_icon = "🔓" if obs["status"] == "مفتوحة" else "🔒"
            text += (
                f"{obs['priority']} {status_icon} <code>{obs['id']}</code>\n"
                f"📌 {obs['title'][:50]}\n"
                f"🏢 {obs['department']} | 📅 {obs['target_date'].strftime('%Y-%m-%d')}\n\n"
            )

    await query.edit_message_text(
        text[:4000], parse_mode="HTML", reply_markup=back_keyboard()
    )


async def sla_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """حالة SLA"""
    query = update.callback_query
    if query:
        await query.answer()

    open_obs = [o for o in observations if o["status"] == "مفتوحة"]
    now = datetime.now()

    for obs in open_obs:
        obs["overdue"] = now > obs["target_date"]

    overdue = [o for o in open_obs if o["overdue"]]
    on_time = [o for o in open_obs if not o["overdue"]]
    total = len(open_obs)
    rate = (len(on_time) / max(total, 1)) * 100

    # شريط التقدم
    filled = int(rate / 10)
    bar = "█" * filled + "░" * (10 - filled)

    text = (
        f"⏱️ <b>حالة SLA</b>\n"
        f"<code>━━━━━━━━━━━━━━━━━━━━</code>\n"
        f"📊 إحصائيات الملاحظات المفتوحة:\n\n"
        f"[{bar}] {rate:.0f}%\n\n"
        f"📋 الإجمالي: <b>{total}</b>\n"
        f"✅ في الموعد: <b>{len(on_time)}</b>\n"
        f"⏰ المتأخرة: <b>{len(overdue)}</b>\n"
        f"<code>━━━━━━━━━━━━━━━━━━━━</code>\n"
    )

    if overdue:
        text += "\n⚠️ <b>الملاحظات المتأخرة:</b>\n"
        for obs in sorted(overdue, key=lambda x: x["target_date"])[:5]:
            days = (now - obs["target_date"]).days
            text += f"• <code>{obs['id']}</code> - متأخر {days} يوم\n"
    else:
        text += "\n✅ لا توجد ملاحظات متأخرة!"

    if query:
        await query.edit_message_text(
            text, parse_mode="HTML", reply_markup=back_keyboard()
        )
    else:
        await update.message.reply_text(
            text, parse_mode="HTML", reply_markup=back_keyboard()
        )


async def critical_obs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض الملاحظات الحرجة"""
    query = update.callback_query
    await query.answer()

    critical = [o for o in observations if "حرج" in o["priority"] and o["status"] == "مفتوحة"]

    if not critical:
        text = "✅ لا توجد ملاحظات حرجة مفتوحة!"
    else:
        text = f"🔴 <b>الملاحظات الحرجة ({len(critical)})</b>\n\n"
        for obs in critical:
            days_left = (obs["target_date"] - datetime.now()).days
            status = f"متبقي {days_left} يوم" if days_left >= 0 else f"متأخر {abs(days_left)} يوم"
            text += (
                f"<code>{obs['id']}</code>\n"
                f"📌 {obs['title'][:60]}\n"
                f"🏢 {obs['department']} | 📅 {status}\n\n"
            )

    await query.edit_message_text(
        text, parse_mode="HTML", reply_markup=back_keyboard()
    )


# ═══════════════════════════════════════════
# معالجة الأزرار
# ═══════════════════════════════════════════


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة ضغطات الأزرار"""
    query = update.callback_query
    await query.answer()

    data = query.data

    if data == "dashboard":
        await dashboard(update, context)
    elif data == "new_obs":
        await new_obs_conversation(update, context)
    elif data == "open_obs":
        await open_points(update, context)
    elif data == "all_obs":
        await all_observations(update, context)
    elif data == "sla":
        await sla_status(update, context)
    elif data == "critical":
        await critical_obs(update, context)
    elif data == "help":
        await help_command(update, context)
    elif data.startswith("prio_"):
        await add_priority(update, context)
    elif data.startswith("days_"):
        await add_days(update, context)


# ═══════════════════════════════════════════
# التشغيل الرئيسي
# ═══════════════════════════════════════════


def main():
    """نقطة الدخول الرئيسية"""
    logger.info("=" * 50)
    logger.info("🚀 امتثال+ - بوت الالتزام التنظيمي")
    logger.info(f"🕐 البدء: {datetime.now()}")
    logger.info("=" * 50)

    app = Application.builder().token(BOT_TOKEN).build()

    # محادثة إضافة ملاحظة
    add_conv = ConversationHandler(
        entry_points=[
            CommandHandler("add", new_obs_conversation),
            CallbackQueryHandler(new_obs_conversation, pattern="^new_obs$"),
        ],
        states={
            ADDING_TITLE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_title)
            ],
            ADDING_PRIORITY: [
                CallbackQueryHandler(add_priority, pattern="^prio_")
            ],
            ADDING_DEPT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, add_department),
            ],
            ADDING_DAYS: [
                CallbackQueryHandler(add_days, pattern="^days_")
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel_conversation)],
    )

    # معالجات الأوامر
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("dashboard", dashboard))
    app.add_handler(CommandHandler("new", new_quick))
    app.add_handler(CommandHandler("open", open_points))
    app.add_handler(CommandHandler("sla", sla_status))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(add_conv)
    app.add_handler(CallbackQueryHandler(button_handler))

    logger.info("✅ البوت جاهز! اضغط Ctrl+C للإيقاف.")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
